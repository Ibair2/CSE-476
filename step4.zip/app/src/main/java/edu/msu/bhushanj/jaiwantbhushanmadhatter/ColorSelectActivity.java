package edu.msu.bhushanj.jaiwantbhushanmadhatter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ColorSelectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_select);
    }

    public void selectColor(int color) {


    }
}
